#' rhdf5filters
#' 
#' This package provides several HDF5 compression filters for use with rhdf5 
#' or other tools using HDF5.
#'
#' @docType package
#' @name rhdf5filters
#'
#' @useDynLib rhdf5filters
#'
NULL
