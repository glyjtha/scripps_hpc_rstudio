#pragma once

/// Filter ID
/// \todo Register with hdf group
#define FILTER_VBZ_ID 32020

#define FILTER_VBZ_VERSION_OPTION                   0
#define FILTER_VBZ_INTEGER_SIZE_OPTION              1
#define FILTER_VBZ_USE_DELTA_ZIG_ZAG_COMPRESSION    2
#define FILTER_VBZ_ZSTD_COMPRESSION_LEVEL_OPTION    3
